
//#include "Terminal.c"
//#include "Server.h"
#include "Application.h"
int main()
{
	appStart();
	
	
}