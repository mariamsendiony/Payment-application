#include "Terminal.h"
EN_terminalError_t getTransactionDate(ST_terminalData_t* termData)
{

	time_t rawtime;
	time(&rawtime);
	struct tm* timeinfo = localtime(&rawtime);
	strftime(termData->transactionDate, sizeof(termData->transactionDate), "%d/%m/%Y", timeinfo);
	puts(termData->transactionDate);
	return OK;
}
EN_terminalError_t isCardExpired(ST_cardData_t cardData, ST_terminalData_t termData)
{
	puts(cardData.cardExpirationDate);
	puts(termData.transactionDate);
	char ey[3];
	ey[0] = cardData.cardExpirationDate[3];
	ey[1] = cardData.cardExpirationDate[4];
	ey[2]= '\0';
	//printf("\n%c %c", cardData.cardExpirationDate[3], cardData.cardExpirationDate[4]);
	char ny[3];
	ny[0] = termData.transactionDate[8];
	ny[1]= termData.transactionDate[9];
	ny[2] = '\0';
	//printf("\n%c %c", termData.transactionDate[8], termData.transactionDate[9]);
	char em[3];
	em[0] = cardData.cardExpirationDate[0];
	em[1] = cardData.cardExpirationDate[1];
	em[2] = '\0';
	//printf("\n%c %c", cardData.cardExpirationDate[0], cardData.cardExpirationDate[1]);
	char nm[3];
	nm[0] = termData.transactionDate[3];
	nm[1] = termData.transactionDate[4];
	nm[2] = '\0';
	//printf("\n%c %c", termData.transactionDate[3], termData.transactionDate[4]);
	int x = strcmp(ey, ny);
	
	if (x > 0)
		
	{
	
		return OK;
	}
	else if(x == 0)
	{
		int y = strcmp(em, nm);
		if (y > 0)
		{
			
			return OK;
		}
		else
		{
			
			return  EXPIRED_CARD;
		}
	}
	else
	{   

		return EXPIRED_CARD;
	}

}

EN_terminalError_t getTransactionAmount(ST_terminalData_t* termData)
{
	float x=0;
	printf("please enter the transaction amount:");
	scanf("\n%f",& x);
	if ((x) <= 0)
	{
		
		
		return INVALID_AMOUNT;

	}
	
	termData->transAmount = x;
	return OK;
}

EN_terminalError_t isBelowMaxAmount(ST_terminalData_t* termData)
{
	if (termData->transAmount > termData->maxTransAmount)
	{
		//printf("more than max\n");
		return EXCEED_MAX_AMOUNT;
	}
	else
	{
		//printf("Below max\n");
		return OK;
	}
}

EN_terminalError_t setMaxAmount(ST_terminalData_t* termData)
{
	termData->maxTransAmount = 30000;
	//printf("\nMax terminal amount");
	//scanf("%f", termData->maxTransAmount);
	if (termData->maxTransAmount <= 0)
	{
		printf("\nMax is negative");
		return  INVALID_MAX_AMOUNT;
	}
	else
	{
		return OK;
	}

}
