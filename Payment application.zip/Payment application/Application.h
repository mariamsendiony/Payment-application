#ifndef APPLICATION_H
#define APPLICATION_H
#include "Server.h"
void appStart(void);

#endif
