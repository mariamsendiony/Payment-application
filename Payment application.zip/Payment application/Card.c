#include"Card.h"
EN_cardError_t getCardHolderName(ST_cardData_t* cardData)
{
	
	    char str[90];
		printf("Enter a 20 to 24 character  name\n");
		gets(str);
		printf("%d\n", strlen(str));
		
		if(strlen(str) >24 || strlen(str)<20) {
			//printf("Wrong name");
			return WRONG_NAME;
		}

		strcpy(cardData->cardHolderName, str);
	    return OK;
}
EN_cardError_t getCardExpiryDate(ST_cardData_t* cardData)
{
	    char str[90];
		printf("\nEnter  Expiration date in the format MM/YY\n");
		gets(str);
		if (strlen(str)!=5 || strlen(str)==0) {
		
			return WRONG_EXP_DATE;
		}
		
		if (str[0] > '1')
		{
			
			return WRONG_EXP_DATE;
		}
		else if (str[0] == '1')
		{
			if (str[1] > '2')
			{
				return WRONG_EXP_DATE;

			}
		}

		strcpy(cardData->cardExpirationDate, str);
		//printf("%s", cardData->cardExpirationDate);
		return OK;
	
}

EN_cardError_t getCardPAN(ST_cardData_t* cardData)
{
	char str[90];
	printf("Enter PAN\n");
	gets(str);
	printf("%d\n", strlen(str));

	if (strlen(str) > 19 || strlen(str) < 16) {
		
		return WRONG_PAN;

	}

	strcpy(cardData->primaryAccountNumber, str);
	//printf("%s", cardData->primaryAccountNumber);
	return OK;
}
