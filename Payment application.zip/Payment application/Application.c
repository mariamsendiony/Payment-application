#include "Application.h"

void appStart(void)
{
	ST_cardData_t carrddata = {
	.cardHolderName = "Mariam Ahmed Abdelwahab ",
	.cardExpirationDate = 6 - 3 - 2001,
	.primaryAccountNumber = "11111111111112111"
	};
	ST_cardData_t* carddata = &(carrddata);
	ST_terminalData_t ddata =
	{
		.maxTransAmount = 2030000,
			.transactionDate = 22 / 06 / 2022,
			.transAmount = 200



	};

	ST_terminalData_t* data = &(ddata);
	ST_transaction trans =
	{
		.cardHolderData.cardExpirationDate = 6 - 3 - 2001,
		.cardHolderData.cardHolderName = "Mariam Ahmed Abdelwahab ",
		//.cardHolderData.primaryAccountNumber = "11111111111112111",
		.terminalData.maxTransAmount = 300000000,
		.terminalData.transactionDate = 18 - 9 - 2022,
		//.terminalData.transAmount = 20,
		.transactionSequenceNumber = 1,
		.transState = APPROVED

	};
	ST_cardData_t* pCardData = &(trans.cardHolderData);
	ST_terminalData_t* term = &(trans.terminalData);
	ST_transaction* transaction = &(trans);

	ST_accountsDB_t* accountRefrence;


	EN_cardError_t x;
	do
	{
	x=getCardHolderName(pCardData);
	} while (x == WRONG_NAME);

	EN_cardError_t y ;
	do
	{
		y=getCardExpiryDate(pCardData);
	} while (y == WRONG_EXP_DATE);

	EN_cardError_t o;
	do
	{
		
		o=getCardPAN(pCardData);
	}while (o == WRONG_PAN);
	getTransactionDate(term);
	EN_terminalError_t  z = isCardExpired(trans.cardHolderData, trans.terminalData);
    if (z == EXPIRED_CARD)
    {
		printf("Expired Card\n");
		exit(0);    }
	
	EN_terminalError_t e=getTransactionAmount(term);
	if (e == INVALID_AMOUNT)
	{
		printf("Invalid amount\n");
		exit(0);
	}
	EN_terminalError_t g=setMaxAmount(term);
	if (g == INVALID_MAX_AMOUNT)
	{	printf("Invalid Max amount\n");
		exit(0);
	}
	EN_terminalError_t h = isBelowMaxAmount(term);
	if (h == EXCEED_MAX_AMOUNT)
	{
		printf("EXCEED_MAX_AMOUNT\n");
		exit(0);
	}
	initialize();
	//EN_serverError_t q =isValidAccount(pCardData);
	//if (q == ACCOUNT_NOT_FOUND)
	//{
	//	printf("ACCOUNT_NOT_FOUND but will save the transaction\n");
	//}
	//EN_serverError_t r = isAmountAvailable(term);
	//if (r ==LOW_BALANCE)
	//{
	//	printf("Low balance but will save transaction\n");
	//}
	EN_transStat_t u = recieveTransactionData(transaction);
	//EN_serverError_t u = isBlockedAccount(tempaccount);
	if (u == DECLINED_STOLEN_CARD)
	{
		printf("Blocked but will save transaction\n");
	}
	else if (u == FRAUD_CARD)
	{
		printf("Invalid account but will save\n");
	}
	else if (u == DECLINED_INSUFFECIENT_FUND)
	{
		printf("DECLINED_INSUFFECIENT_FUND but will save\n");
	}
	EN_serverError_t s=saveTransaction(transaction);
	if (s == SAVING_FAILED)
	{
		printf("The transaction can't be saved\n");
		
	}
	else
	{
		printf("The transaction was saved\n");
	}
	

}
