#include "Server.h"
void initialize()
{
	accountdb[0].balance = 30000;
	strcpy(accountdb[0].primaryAccountNumber, "1111111111111111111");
	accountdb[0].state = RUNNING;
	//accountdb[1].balance = 200000;
	//strcpy(accountdb[1].primaryAccountNumber, "2222222222222222222");
	strcpy(transdb[0].cardHolderData.cardHolderName, "00000000000000000000");
	strcpy(transdb[0].cardHolderData.cardExpirationDate, "00000");
	strcpy(transdb[0].cardHolderData.primaryAccountNumber, "000000000000000000");
	transdb[0].terminalData.maxTransAmount = 0;
	transdb[0].transactionSequenceNumber = 0;
	transdb[0].transState = 0;
	
	///////////////////////////////////////////////////////////////
	accountdb[1].balance = 40000;
	strcpy(accountdb[1].primaryAccountNumber, "2222222222222222222");
	accountdb[1].state = RUNNING;
	strcpy(transdb[1].cardHolderData.cardHolderName, "00000000000000000000");
	strcpy(transdb[1].cardHolderData.cardExpirationDate, "00000");
	strcpy(transdb[1].cardHolderData.primaryAccountNumber, "000000000000000000");
	transdb[1].terminalData.maxTransAmount = 0;
	transdb[1].transactionSequenceNumber = 0;
	transdb[1].transState = 0;
	////////////////////////////////////////////////////////////////
	accountdb[2].balance = 70000;
	strcpy(accountdb[2].primaryAccountNumber, "3333333333333333333");
	accountdb[2].state = RUNNING;
	strcpy(transdb[2].cardHolderData.cardHolderName, "00000000000000000000");
	strcpy(transdb[2].cardHolderData.cardExpirationDate, "00000");
	strcpy(transdb[2].cardHolderData.primaryAccountNumber, "000000000000000000");
	transdb[2].terminalData.maxTransAmount = 0;
	transdb[2].transactionSequenceNumber = 0;
	transdb[2].transState = 0;
	///////////////////////////////////////////////////////////////
	accountdb[3].balance = 5000;
	strcpy(accountdb[3].primaryAccountNumber, "4444444444444444444");
	accountdb[3].state = RUNNING;
	strcpy(transdb[3].cardHolderData.cardHolderName, "00000000000000000000");
	strcpy(transdb[3].cardHolderData.cardExpirationDate, "00000");
	strcpy(transdb[3].cardHolderData.primaryAccountNumber, "000000000000000000");
	transdb[3].terminalData.maxTransAmount = 0;
	transdb[3].transactionSequenceNumber = 0;
	transdb[3].transState = 0;
	///////////////////////////////////////////////////////////////////
	accountdb[4].balance = 11000;
	strcpy(accountdb[4].primaryAccountNumber, "5555555555555555555");
	accountdb[4].state = BLOCKED;
	strcpy(transdb[4].cardHolderData.cardHolderName, "00000000000000000000");
	strcpy(transdb[4].cardHolderData.cardExpirationDate, "00000");
	strcpy(transdb[4].cardHolderData.primaryAccountNumber, "000000000000000000");
	transdb[4].terminalData.maxTransAmount = 0;
	transdb[4].transactionSequenceNumber = 0;
	transdb[4].transState = 0;


}

EN_transStat_t recieveTransactionData(ST_transaction* transData)
{
	FILE* fPtr;
	fPtr = fopen("Transaction.txt", "a+");
	if (fPtr == NULL)
	{
		/* File not created hence exit */
	
		exit(EXIT_FAILURE);
	}
	if (index == 255||fPtr==EOF)
	{   
		fclose(fPtr);
		return INTERNAL_SERVER_ERROR;

	}
	
	else
	{
		//EN_serverError_t x;
		//int flag = 0;
		
	     /*for (int i = 0; i < 255; i++)
		{
			printf("%s\n", transData->cardHolderData.primaryAccountNumber);
			printf("%s\n", accountdb[0].primaryAccountNumber);
			if (strcmp(transData->cardHolderData.primaryAccountNumber, accountdb[i].primaryAccountNumber) == 0)
			{
				index = i;
				printf("happy");
				x= OK;
				flag = 1;

			}

		}
		if (flag == 0)
		{
			x = DECLINED_STOLEN_CARD;
		}
		
		
		if (x == DECLINED_STOLEN_CARD)
		{
			printf("Card declined");
			return DECLINED_STOLEN_CARD;
		}
		*/
		EN_serverError_t x = isValidAccount(&(transData->cardHolderData));
		if (x == ACCOUNT_NOT_FOUND)
		{
			printf("not found\n");
			return FRAUD_CARD;
		}
		EN_serverError_t y = isAmountAvailable(&(transData->terminalData));
		/*if (accountdb[index].balance > transData->terminalData.transAmount)
		{
			printf("ok");
			return OK;

		}
		else
		{
			printf("err blance");
			return  LOW_BALANCE;

		}

		if (y == LOW_BALANCE)
		{
			return DECLINED_INSUFFECIENT_FUND;
		}
		*/
		if (y == LOW_BALANCE)
		{
			printf("loww\n");
			return DECLINED_INSUFFECIENT_FUND;
		}
		EN_serverError_t z = isBlockedAccount(tempaccount);
		if (z == BLOCKED_ACCOUNT) {
			printf("blocked");
			return DECLINED_STOLEN_CARD;
		}

			accountdb[index].balance = accountdb[index].balance - (transData->terminalData.transAmount);
			printf("\n New balance=%f", accountdb[index].balance);
			return APPROVED;
	}
}

EN_serverError_t isValidAccount(ST_cardData_t* cardData)
{//printf("%s\n", accountdb[0].primaryAccountNumber);
	
	for (int i = 0; i < 255; i++)
	{
		if (strcmp(cardData->primaryAccountNumber, accountdb[i].primaryAccountNumber) == 0 )
		{
			index = i;
			tempaccount = (accountdb + i);
			//printf("\nValid account");
			return OK;

		}		
	
	}
	
		//printf("\nInvalid account");
		return ACCOUNT_NOT_FOUND;

}

EN_serverError_t isAmountAvailable(ST_terminalData_t* termData)
{
	//printf("%d", index);
	//printf("\nbalance %f", accountdb[index].balance);
	if (accountdb[index].balance > termData->transAmount)
	{
		//printf("\namount available");
		return OK;
		
	}
	else
	{
	//	printf("\nInsufficient balance");
		return  LOW_BALANCE;
	
	}
	
}

EN_serverError_t saveTransaction(ST_transaction* transData)
{
		FILE* fPtr;
	fPtr = fopen("Transaction.txt", "a+");
	if (fPtr == NULL)
	{
		/* File not created hence exit */
		printf("Unable to create file.\n");
		exit(EXIT_FAILURE);
	}
	EN_transStat_t y = recieveTransactionData(transData);
	if (y == INTERNAL_SERVER_ERROR)
	{
		return SAVING_FAILED;
	}
	char newline;
	fseek(fPtr, 0L, SEEK_SET);
	int lines = 0;
	while ((newline = fgetc(fPtr)) != EOF) {
		if ((newline == '\n'))
			lines++;
	}
	if (lines==0)
	{
		transData->transactionSequenceNumber = 0;
		transData->transState = y;
		switch (y)
		{
		case(0):
			fflush(fPtr);
			fprintf(fPtr, "%s  %s  %s %s %f %f %d %d Approved\n", transData->cardHolderData.cardHolderName, transData->cardHolderData.primaryAccountNumber,transData->cardHolderData.cardExpirationDate, transData->terminalData.transactionDate, transData->terminalData.transAmount,transData->terminalData.maxTransAmount,transData->transactionSequenceNumber, transData->transState);
			fflush(fPtr);
			break;
		case(1):

			fflush(fPtr);
			fprintf(fPtr, "%s  %s  %s %s %f %f %d %d LOW_BAlANCE\n", transData->cardHolderData.cardHolderName, transData->cardHolderData.primaryAccountNumber, transData->cardHolderData.cardExpirationDate, transData->terminalData.transactionDate, transData->terminalData.transAmount, transData->terminalData.maxTransAmount, transData->transactionSequenceNumber, transData->transState);
			fflush(fPtr);
			
			break;
		case(2):
			fflush(fPtr);
			fprintf(fPtr, "%s  %s  %s %s %f %f %d %d DECLINED_STOLEN_CARD\n", transData->cardHolderData.cardHolderName, transData->cardHolderData.primaryAccountNumber, transData->cardHolderData.cardExpirationDate, transData->terminalData.transactionDate, transData->terminalData.transAmount, transData->terminalData.maxTransAmount, transData->transactionSequenceNumber, transData->transState);
			fflush(fPtr);
			break;
		case(3):
			fflush(fPtr);
			fprintf(fPtr, "%s  %s  %s %s %f %f %d %d FRAUD_CARD\n", transData->cardHolderData.cardHolderName, transData->cardHolderData.primaryAccountNumber, transData->cardHolderData.cardExpirationDate, transData->terminalData.transactionDate, transData->terminalData.transAmount, transData->terminalData.maxTransAmount, transData->transactionSequenceNumber, transData->transState);
			fflush(fPtr);
			break;
	    

		}
		return OK;
	}
	else
	{
		
		transData->transState = y;
		switch (y)
		{
		case(0):
			fflush(fPtr);
			fprintf(fPtr, "%s  %s  %s %s %f %f %d %d Approved\n", transData->cardHolderData.cardHolderName, transData->cardHolderData.primaryAccountNumber, transData->cardHolderData.cardExpirationDate, transData->terminalData.transactionDate, transData->terminalData.transAmount, transData->terminalData.maxTransAmount, lines, transData->transState);
			fflush(fPtr);
			break;
		case(1):

			fflush(fPtr);
			fprintf(fPtr, "%s  %s  %s %s %f %f %d %d LOW_BAlANCE\n", transData->cardHolderData.cardHolderName, transData->cardHolderData.primaryAccountNumber, transData->cardHolderData.cardExpirationDate, transData->terminalData.transactionDate, transData->terminalData.transAmount, transData->terminalData.maxTransAmount, lines, transData->transState);
			fflush(fPtr);
			break;
		case(2):
			fflush(fPtr);
			fprintf(fPtr, "%s  %s  %s  %s %f %f %d %d DECLINED_STOLEN_CARD\n", transData->cardHolderData.cardHolderName, transData->cardHolderData.primaryAccountNumber,transData->cardHolderData.cardExpirationDate, transData->terminalData.transactionDate, transData->terminalData.transAmount,transData->terminalData.maxTransAmount, lines, transData->transState);
			fflush(fPtr);
			break;
		case(3):
			fflush(fPtr);
			fprintf(fPtr, "%s  %s  %s  %s %f %f %d %d FRAUD_CARD\n", transData->cardHolderData.cardHolderName, transData->cardHolderData.primaryAccountNumber,transData->cardHolderData.cardExpirationDate, transData->terminalData.transactionDate, transData->terminalData.transAmount,transData->terminalData.maxTransAmount, lines, transData->transState);
			fflush(fPtr);
			break;
		}
		return OK;
	}


}

EN_serverError_t isBlockedAccount(ST_accountsDB_t* accountRefrence)
{
	if (accountRefrence->state == BLOCKED) {
		return BLOCKED_ACCOUNT;
	}
	else {
		return OK;
	}
	//return EN_serverError_t();
}
